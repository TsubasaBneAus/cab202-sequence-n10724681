extern volatile uint8_t digit1;
extern volatile uint8_t digit2;

void display_hex(uint8_t sequence_index);