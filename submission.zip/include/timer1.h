extern volatile uint8_t pb_debounced;
extern volatile uint8_t display_state;

void timer1_init(void);