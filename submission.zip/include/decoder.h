extern char test_sequence[33];
extern uint8_t serial_command_test;

void decode_sequence(uint8_t sequence_index, uint8_t decoded_sequence[24]);